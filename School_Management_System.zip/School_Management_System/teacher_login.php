<?php
  include "database.php";
  session_start();
?>



 <!DOCTYPE html>
<html lang="en">
  <head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="js/bootstrap.js">

     <title>C.O.LESTHAKIR</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    
    <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" type="text/css" href="css/st.css">



  </head>
  <body>
    <div class="py-2 bg-primary">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0">
          <div class="col-lg-12 d-block">
            <div class="row d-flex">
              <div class="col-md-5 pr-4 d-flex topper align-items-center">
                <div class="icon bg-fifth mr-2 d-flex justify-content-center align-items-center"><span class="icon-map"></span></div>
                <span class="text">198 Main Street, Ninthavur</span>
              </div>
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon bg-secondary mr-2 d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
                <span class="text">lesthakir@email.com</span>
              </div>
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon bg-tertiary mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
                <span class="text">+ 9477123869</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco_navbar ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">
        <a class="navbar-brand" href="index.php">C.O Lesthakir<br>International school</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="index.php" class="nav-link pl-0">Home</a></li>
            <li class="nav-item"><a href="about.php" class="nav-link">About Us</a></li>
            <li class="nav-item"><a href="admin.php" class="nav-link">Admin</a></li>
            <li class="nav-item active"><a href="teacher_login.php" class="nav-link">Teacher</a></li>
            <li class="nav-item"><a href="courses.php" class="nav-link">Courses</a></li>
            <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->
    

  <div class="container">
    <div class="row">
      <div class="col-md-5">
        <div class="login" align="center">
          <h1 class="heading">  Teacher's Login </h1>
          <div class="log">
            <?php
              if(isset($_POST["login"]))
              {
                $sql="select * from staff where TNAME='{$_POST["name"]}'and TPASS='{$_POST["pass"]}'";
                $res=$db->query($sql);
                if($res->num_rows>0)
                {
                  $ro=$res->fetch_assoc();
                  $_SESSION["TID"]=$ro["TID"];
                  $_SESSION["TNAME"]=$ro["TNAME"];
                  echo "<script>window.open('teacher.php','_self');</script>";
                }
                else
                {
                  echo "<p class='bg-danger'><big>Invalid Username or Password</big></div>";
                }
              }   
            
            ?>
          

       <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
           <label class="label control-label"><span class="icon-user"></span>&nbsp; &nbsp; User Name</label><br>
              <input type="text" name="name"  class="form-control"><br><br>
            <label class="label control-label"><span class="icon-lock"></span>&nbsp; &nbsp;Password</label><br>
              <input type="password" name="pass"  class="form-control"><br>
                      <div class="row">

          <div class="col-md-6">
            <input type="checkbox"><small>Remember me</small>
          </div>

          <div class="col-md-6">
          <a href="#"><p class="text-right"></p></a>
        </div>
        </div>

                    <button type="submit" class="btn btn-primary" name="login" >Login</button>
                            <p class="text-center">Not a member ask for admin <a href="#"></a></p>


  
          </form><br>            </form><br>
        </div>
      </div>
          
        </div>
              <div class="col-md-2"></div>
              <br><br><br><br><center><br><br>
                <img src = "images\th.png" alt="loc" width="500" height="500">
              

      </div>
  </div>

      
  <div class="footer">
        <p><b><center><h4>  Copyright &copy; SMS  </h4></center></b></p>
        </div>
    



  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>
<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM staff WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> Admin - Dashboard</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>
	
	<body class = "back" id="page-top">
		  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="index.php">Teacher Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="teacher.php">Teacher Home</a>&nbsp;&nbsp;
				<a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="teacher_login.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="teacher.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="teacher_home.php">
        	          <i class="fas fa-fw fa-folder"></i>

        	          <span>Profile</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="handle_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_stud.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Students</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_stud_teach.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="tech_view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Add Marks</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Marks</span></a>
      </li>
   
	 
       
	  
	  
    </ul>
	<div id="content-wrapper">

 	<div class="container-fluid">



 				<div class="card mb-3">
 					          <div class="alert alert-warning">
 					     &nbsp;&nbsp; <h1 class="text" align = "center">	Welcome 	<?php echo $_SESSION["TNAME"]; ?></h1><hr>
</div>
 					                    <div class="card-body">

<div class="container">
<div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="alert alert-info"><h1> Class Details</h1></div>
                            <div class="card-body">
                            	<center>				<img src="images/clas.jpg" width="600" height="300" />

                            			</center><br><br>
					
					<div class="lbox1">
					<?php
						if(isset($_POST["submit"]))
						{
							 $sq="insert into hclass(TID,CLA,SEC,SUB) values ('{$_SESSION["TID"]}','{$_POST["cla"]}','{$_POST["sec"]}','{$_POST["sub"]}')";
							if($db->query($sq))
							{
								echo "<p class='bg-success'>Insert Success..</div>";
							}
							else
							{
								echo "<p class='bg-danger'>Insert Failed..</div>";
							}
		
						}
					
					
					?>		
						
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					<i class="fa fa-laptop fa" aria-hidden="true">&nbsp;&nbsp;</i>

					<label>Class</label><br>
						
						<select name="cla" class="form-control">
							<?php
								$sl="select DISTINCT(CNAME) from class"; //avoide repetation
								$r=$db->query($sl);
								 if($r->num_rows>0)
								 {
									 echo "<option value=''>Select</option>";
									 while($ro=$r->fetch_assoc())
									 {
										 echo "<option value='{$ro["CNAME"]}'>{$ro["CNAME"]}</option>";
									 }
								 }
							
							
							?>
					
						</select>
					<br><br>
					<i class="fa fa-columns gutter fa" aria-hidden="true">&nbsp;&nbsp;</i>

					<label>Section</label><br>
					
						<select name="sec"  class="form-control">
						<?php
							$sl="select DISTINCT(CSEC) from class";
							$r=$db->query($sl);
								if($r->num_rows>0)
								{
									echo "<option value=''>Select</option>";
									while($ro=$r->fetch_assoc())
									{
										echo "<option value='{$ro["CSEC"]}'>{$ro["CSEC"]}</option>";
									}
								}
						
						
						
						
						?>
						
						
						</select><br></br>
					<i class="fa fa-book fa" aria-hidden="true">&nbsp;&nbsp;</i>

							<label>Subject</label><br>
					
						<select name="sub" class="form-control">
						<?php
							$s="select * from sub";
							$re=$db->query($s);
							if($re->num_rows>0)
							{
								echo "<option value=''>Select</option>";
								while($r=$re->fetch_assoc())
								{
								echo "<option value='{$r["SNAME"]}'>{$r["SNAME"]}</option>";
								}
							}
						
						
						?>
						</select>
						
					<br><br>

					<button type="submit" class="btn btn-primary" name="submit">Add  Details</button>
					</form>
					
										
					</div><br><br>
					
					
					
					<div class="rbox1">
						<?php
						if(isset($_GET["mes"]))
						{
							echo"<p class='bg-warning'>{$_GET["mes"]}</div>";	
						}
					
					?>
				 <div class="card mb-3">
				        	 <div class="alert alert-danger">
            <i class="fas fa-table"></i>
            Class Data Table </div>
                        <div class="table">
            <div class="table-responsive">
              <table class="table table-bordered table-hover table-striped" id="dataTable" width="100%" cellspacing="0" align="center">
               <tbody>


						<tr class="text-center">
							<th>S.No</th>
							<th>Class Name</th>
							<th>Section</th>
							<th>Subject</th>
							<th>Delete</th>
						</tr>
						<?php
							$s="select * from hclass";
							$res=$db->query($s);
							if($res->num_rows>0)
							{
								$i=0;
								while($r=$res->fetch_assoc())
								{
									$i++;
									echo"
									<tr>
										<td>{$i}</td>
										<td>{$r["CLA"]}</td>
										<td>{$r["SEC"]}</td>
										<td>{$r["SUB"]}</td>
										<td><a href='hclass.php?id={$r["HID"]}' class='btn btn-danger'>Delete</a></td>
									</tr>
									
									";
								}
							}
						
						
						
						?>
					
		</tbody></center></table></div></div></div></div>
	
				<div class="footer1">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
				</div>
	</body>
</html>













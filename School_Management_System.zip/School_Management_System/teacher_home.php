<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_home.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM staff WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> Teacher - Dashboard</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>
	
	<body class = "back" id="page-top">
		  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="">Teacher Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="teacher.php">Teacher Home</a>&nbsp;&nbsp;
				<a href="teacher_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="teacher_login.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="teacher.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="teacher_home.php">
        	          <i class="fas fa-fw fa-folder"></i>
        	          <span>Profile</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="handle_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_stud.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Students</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_stud_teach.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="tech_view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Add Marks</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Marks</span></a>
      </li>
   
	 
        
	  
    </ul>
	<div id="content-wrapper">

 	<div class="container-fluid">

 	 <div class="alert alert-danger">

					<h1 class="text" align = "center"> Teacher Profile</h1><hr></div>
 				<div class="card mb-3">
 					          <div class="card-header">
 					          	<div class="alert alert-success">

 					          <i class="fas fa-chart-area"></i>&nbsp;&nbsp; Add Teacher profile</div>
 					                    <div class="card-body">
          </div>

<div class="container">
<div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header"><h1><?php echo $_SESSION["TNAME"]; ?> </h1></div>
                            <div class="card-body">
					
					<div class="lbox1">
					
					
					<?php
						if(isset($_POST["submit"]))
						{
							$target="staff/";
							$target_file=$target.basename($_FILES["img"]["name"]);
							
							if(move_uploaded_file($_FILES['img']['tmp_name'],$target_file))
							{
								$sql="update staff set PNO='{$_POST["pno"]}',MAIL='{$_POST["mail"]}',PADDR='{$_POST["addr"]}',IMG='{$target_file}'where TID={$_SESSION["TID"]}";
								$db->query($sql);
								echo "<p class='bg-success'><b>Insert Success</b></div>";
							}
							
						}
					
					
					?>
					<div class="container" style="padding-left:20%;">
			<div class="row">
				<div class="col-lg-6"><center>
					               <table class="table table-user-information">
					               						<div class = "side" >

					<div class="rbox1">
					
							<tr><td colspan="4"><center><img src="<?php echo $row["IMG"] ?>" height="200" width="200" alt="upload Pending" ></center>
							</td></tr>
							<tr><th>Name </th> <td><?php echo $row["TNAME"] ?> </td></tr>
							<tr><th>Qualification </th> <td><?php echo $row["QUAL"] ?>  </td></tr>
							<tr><th>Salary </th> <td> <?php echo $row["SAL"] ?>  </td></tr>
							<tr><th>Phone No </th> <td> <?php echo $row["PNO"] ?> </td></tr>
							<tr><th>E - Mail </th> <td> <?php echo $row["MAIL"] ?> </td></tr>
							<tr><th>Address </th> <td> <?php echo $row["PADDR"] ?> </td></tr></center>

						</table>
				</div></div>
					
						
					<form  enctype="multipart/form-data" role="form"  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
							<i class="fa fa-phone fa" aria-hidden="true">&nbsp;&nbsp;</i>
							<label>  Phone No</label><br>
							<input type="text" maxlength="10"  name="pno" class="form-control" placeholder="mobile"><br><br>
							<i class="fa fa-envelope fa" aria-hidden="true">&nbsp;&nbsp;</i>
							<label>  E - Mail</label><br>
						<input type="email" maxlength="100"  name="mail" class="form-control" placeholder="@.gmail.com"><br><br>
							<i class="fa fa-user fa" aria-hidden="true">&nbsp;&nbsp;</i>

							<label>  Address</label><br>
							<input type="add" maxlength="100"  name="addr" class="form-control" placeholder="Homw town"><br><br>
							<i class="fa fa-camera fa" aria-hidden="true">&nbsp;&nbsp;</i>

							<label> Image</label><br>
							<input type="file"  class="input3" required name="img"><br><br>
						<button type="submit" class="btn btn-primary" name="submit">Add Profile Details</button>
						</form>
					</div><br><br>		
		
						<div class="footer">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
		</div>

	</body>
</html>
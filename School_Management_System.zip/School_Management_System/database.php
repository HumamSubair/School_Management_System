<?php
	$db=new mysqli("localhost","root","","school");

	if(!$db) // ! symbol is meaning  not connected

	{
		echo "failed";
	}
	
?>
<!-- db is variable & new is object name & 4 arqument pass 1.Server name 2. user name 3. password 4. db name
	-->
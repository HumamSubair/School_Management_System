<?php
  include"database.php";
  session_start();
  if(!isset($_SESSION["TID"]))
  {
    echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
    
  } 
  
  if(isset($_GET["rno"]))   // rollno check
  {
    $sql="select * from student where RNO='{$_GET["rno"]}'";
    $res=$db->query($sql);
    if($res->num_rows<=0)
    {
      header("location:add_mark.php?err=Invalid Register no..");
    }
    else
    {
      $rows=$res->fetch_assoc();
      $class=$rows["SCLASS"];
      $regno=$_GET["rno"];
    }
  }
?>

<!DOCTYPE html>
<html>
	<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> Admin - Dashboard</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>
	
	<body class = "back" id="page-top">
		  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="index.php">Teacher Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="teacher.php">Teacher Home</a>&nbsp;&nbsp;
				<a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="teacher_login.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="teacher.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="teacher_home.php">
        	          <i class="fas fa-fw fa-folder"></i>

        	          <span>Profile</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="handle_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_stud.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Students</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_stud_teach.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="tech_view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Add Marks</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Marks</span></a>
      </li>
   
	 
        
	  
	  
    </ul>
	<div id="content-wrapper">

 	<div class="container-fluid">



 				<div class="card mb-3">
 					          <div class="alert alert-danger">
 					     &nbsp;&nbsp; <h1 class="text" align = "center">	Welcome 	<?php echo $_SESSION["TNAME"]; ?></h1><hr>
</div>
 					                    <div class="card-body">

<div class="container">
<div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="alert alert-info"><h6>  Marks Details</h6></div>
                            <div class="card-body">
                                 <center><img src="images/ex.jpg" width="400" height="250"></center><br>

					
		<div id="section">
        
        
        
        <div class="section">
          
          <?php
            if(isset($_POST["submit"]))
            {
              $sq="insert into mark(REGNO,SUB,MARK,TERM,CLASS) values ('{$_POST["regno"]}','{$_POST["sub"]}','{$_POST["mark"]}','{$_POST["etype"]}','{$_POST["class"]}')";
              if($db->query($sq))
              {
                echo "<p class='bg-success'><b>Insert Success</b></div>";
              }
              else
              {
                echo "<p class='bg-danger'>Insert Failed</div>";
              }
              
            }
          
          
          
          ?>

					<form method="post" action="<?php echo $_SERVER["REQUEST_URI"];?>"> <!--REDONLY IS USE NOT CHANGE -->
            <div class="lbox">
              <label> Register No</label><br>
              <input type="text" style="background:white;" value="<?php echo $regno;?>" class="form-control" name="regno" readonly><br><br> 
              
              <label>Class</label><br>
              <input type="text" style="background:white;"  value="<?php echo $class ?>" class="form-control" name="class" readonly><br><br>
            
              <label> Select Term</label><br>
              <select name="etype" required class="form-control">
                <option value="">Select</option>
                <option value="I-Term">I-Term</option>
                <option value="II-Term">II-Term</option>
                <option value="III-Term">III-Term</option>
              </select>
              <br><br>
            </div>
            <div class="rbox">
              
            <label>Subject</label><br>                          <!--admin add the subject only -->
              <select name="sub" required class="form-control">
            
                <?php 
                   $s="SELECT *  FROM sub";
                  $re=$db->query($s);
                    if($re->num_rows>0)
                      {
                        echo"<option value=''>Select</option>";
                        while($r=$re->fetch_assoc())
                        {
                          echo "<option value='{$r["SNAME"]}'>{$r["SNAME"]}</option>";
                        }
                      }
                ?>
              </select>
              <br><br>
              <label >Mark :</label><br>
              <input class="form-control" name="mark"  id="mark" type="mark" required>
              <br><br>
              <button type="submit" class="btn btn-primary" name="submit"> Add Mark Details</button>
          </form>   </div>
	
	
				<div class="footer1">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
				</div>
	</body>
</html>













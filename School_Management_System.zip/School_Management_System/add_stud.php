<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM staff WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> Admin - Dashboard</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>
	
	<body class = "back" id="page-top">
		  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="index.php">Teacher Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="teacher.php">Teacher Home</a>&nbsp;&nbsp;
				<a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="teacher_login.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="teacher.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="teacher_home.php">
        	          <i class="fas fa-fw fa-folder"></i>

        	          <span>Profile</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="handle_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_stud.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Students</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_stud_teach.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="tech_view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Add Marks</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Marks</span></a>
      </li>
   
	 
       
	  
	  
    </ul>
	<div id="content-wrapper">

 	<div class="container-fluid">



 				<div class="card mb-3">
 					          <div class="alert alert-success">
 					     &nbsp;&nbsp; <h1 class="text" align = "center">	Welcome 	<?php echo $_SESSION["TNAME"]; ?></h1><hr>
							</div>
 					        </div>            <div class="card-body">

			<div class="container">
				<div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="alert alert-info"><h1> Add Student </h1></div>
                            		<center><img src="images/red.jpg" width="400" height="250"></center><br>

                          	<div class="section">
					
					<?php
						if(isset($_POST["submit"]))
						{
							$edate=$_POST["da"].'-'.$_POST["mo"].'-'.$_POST["ye"];
							$target="student/";
							$target_file=$target.basename($_FILES["img"]["name"]);	//img upload
					if(move_uploaded_file($_FILES['img']['tmp_name'],$target_file)) //move 2 place one is student folder & temporary storage area
							{
								$sq="insert into student(RNO,NAME,FNAME,DOB,GEN,PHO,MAIL,ADDR,SCLASS,SSEC,SIMG,TID) values('{$_POST["rno"]}','{$_POST["name"]}','{$_POST["fname"]}','{$edate}','{$_POST["gen"]}','{$_POST["pho"]}','{$_POST["email"]}','{$_POST["addr"]}','{$_POST["cla"]}','{$_POST["sec"]}','{$target_file}','{$_SESSION["TID"]}')";
								
								if($db->query($sq))
								{
									echo "<p class='bg-success'>Insert Success</p>";
								}
								else
								{
									echo "<p class='bg-danger'>Insert Failed</p>";
								}
							}
							
						}
					
					
					
					
					
					
					?>
						
					<form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER["PHP_SELF"];?>">
				<div class="lbox">	&nbsp;&nbsp;&nbsp;					
					<i class="fa fa-lock fill fa" aria-hidden="true">&nbsp;&nbsp;</i>
					<label> ID</label><br>
						<?php
							$no="S101";
							$sql="select * from student order by ID desc limit 1"; // student table id desenting order limit 1.
							$res=$db->query($sql);
							if($res->num_rows>0)
							{
								$row1=$res->fetch_assoc();
								$no=substr($row1["RNO"],1,strlen($row1["RNO"]));
								$no++;	//record increase
								$no="S".$no;
							}
						
						
						
						?>

					<input type="text" class="form-control" name="rno" value="<?php echo $no;?>" readonly  ><br><br>&nbsp;&nbsp;&nbsp;
					<i class="fa fa-user fa" aria-hidden="true">&nbsp;&nbsp;</i>

					<label> Student Name</label><br>
					<input type="text" class="form-control" name="name"><br><br>&nbsp;&nbsp;&nbsp;
					<i class="fa fa-address-book fa" aria-hidden="true">&nbsp;&nbsp;</i>

					<label> Father Name</label><br>
					<input type="text" class="form-control" name="fname"><br><br>
					&nbsp;&nbsp;&nbsp;
					<i class="fa fa-calendar fa" aria-hidden="true">&nbsp;&nbsp;</i>	
					<label>  Date of Birth</label><br>&nbsp;&nbsp;&nbsp;
					<select name="da" class="input5">
						<option value="">Date</option>
						<option value="1">1 </option>
						<option value="2">2 </option>
						<option value="3">3 </option>
						<option value="4">4 </option>
						<option value="5">5 </option>
						<option value="6">6 </option>
						<option value="7">7 </option>
						<option value="8">8 </option>
						<option value="9">9 </option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option>
						<option value="24">24</option>
						<option value="25">25</option>
						<option value="26">26</option>
						<option value="27">27</option>
						<option value="28">28</option>
						<option value="29">29</option>
						<option value="30">30</option>
						<option value="31">31</option>
						</select>&nbsp;&nbsp;&nbsp;&nbsp;
					<select name="mo" class="input5">
						<option> Month</option>
						<option value="01">Jan</option>
						<option value="02">Feb</option>
						<option value="03">Mar</option>
						<option value="04">Apr</option>
						<option value="05">May</option>
						<option value="06">Jun</option>
						<option value="07">Jul</option>
						<option value="08">Aug</option>
						<option value="09">Sep</option>
						<option value="10">Oct</option>
						<option value="11">Nov</option>
						<option value="12">Dec</option>
					</select>&nbsp;&nbsp;&nbsp;&nbsp;
					<select name="ye" class="input5">
						<option value="">Select Year</option>
						<option value="2018">2018</option>
						<option value="2017">2017</option>
						<option value="2016">2016</option>
						<option value="2015">2015</option>
						<option value="2014">2014</option>
						<option value="2013">2013</option>
						<option value="2012">2012</option>
						<option value="2011">2011</option>
						<option value="2010">2010</option>
						<option value="2009">2009</option>
						<option value="2008">2008</option>
						<option value="2007">2007</option>
						<option value="2006">2006</option>
						<option value="2005">2005</option>
						<option value="2004">2004</option>
						<option value="2003">2003</option>
						<option value="2002">2002</option>
						<option value="2001">2001</option>
					</select><br><br>	&nbsp;&nbsp;&nbsp;				
					<i class="fa fa-male fa" aria-hidden="true">&nbsp;&nbsp;</i>
					<i class="fa fa-female fa" aria-hidden="true">&nbsp;&nbsp;</i>
					<label>Gender</label><br>&nbsp;&nbsp;&nbsp;
					<select name="gen" required class="form-control">
							<option value="">Select</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
					</select><br><br>&nbsp;&nbsp;
					<i class="fa fa-user fa" aria-hidden="true">&nbsp;&nbsp;</i>

					<label> Phone No</label><br>&nbsp;&nbsp;
					<input type="text" class="form-control" maxlength="20" name="pho" placeholder="mobile"><br><br>
				</div>
				
				<div class="rbox">&nbsp;&nbsp;&nbsp;
				<i class="fa fa-home fa" aria-hidden="true">&nbsp;&nbsp;</i>

				<label> Parent's Mail Id</label><br>&nbsp;&nbsp;&nbsp;
					<input type="email" class="form-control" name="email"><br><br>&nbsp;&nbsp;&nbsp;
										<i class="fa fa-address-card fa" aria-hidden="true">&nbsp;&nbsp;</i>

					<label>  Address</label><br>&nbsp;&nbsp;&nbsp;
					<input type="Address" class="form-control" name="addr"><br><br>&nbsp;&nbsp;&nbsp;
									<i class="fa fa-laptop fa" aria-hidden="true">&nbsp;&nbsp;</i>

					<label>Class</label><br>
					<select name="cla" required class="form-control">
				
						<?php 
							 $sl="SELECT DISTINCT(CNAME) FROM class";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["CNAME"]}'>{$ro["CNAME"]}</option>";
										}
									}
						?>
					
					</select>
					<br><br>	&nbsp;&nbsp;&nbsp;				
					<i class="fa fa-keyboard fa" aria-hidden="true">&nbsp;&nbsp;</i>

						<label>Section</label><br>
						<select name="sec" required class="form-control">
						<?php 
							 $sl="SELECT DISTINCT(CSEC) FROM class";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["CSEC"]}'>{$ro["CSEC"]}</option>";
										}
									}
						?>
					
					</select><br></br>	
					&nbsp;&nbsp;&nbsp;&nbsp;
									<i class="fa fa-camera fa" aria-hidden="true">&nbsp;&nbsp;</i>					
									<label> Image</label><br>&nbsp;&nbsp;&nbsp;
					<input type="file"  class="input3" required name="img">
			
				</form><br><br>&nbsp;&nbsp;&nbsp;
				
					<button type="submit" class="btn btn-primary" name="submit">Add Student Details</button><br><br><br><br>
				</div>
				
				
				
		</div>
			
			<div class="footer1">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
				</div>
				
	</body>
	
</html>
	
				











<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
		<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> Add subject</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>

			<body class = "back" id="page-top">
		  	<nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="#">Admin Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="admin_home.php">Admin Home</a>&nbsp;&nbsp;
				<a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="logout.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="add_sub.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="admin_home.php">
        	          <i class="fas fa-fw fa-folder"></i>

        	          <span>School Information</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="add_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_sub.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Subject</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="add_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Staff</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="view_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View staff</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="set_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Set Exam</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="student.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
       
	  
	  
    </ul>


 	<div class="container-fluid">

 
          	<h1 class="alert alert-warning"><font >		Welcome 	<?php echo $_SESSION["ANAME"]; ?></font></h1>

       



<div class="section">
			
				
				<div class="content" >


	
		<center>						<h2 ><center><font color="#DE1B85">&nbsp;&nbsp;&nbsp;Add Subject Details</font></center> </h2><br>

		<img src="images/all.jpg" width="600" height="350" class="rounded-circle">
		</center><br>
			
			<div id="section">
				
				
			<div class="section">
					
				<?php
							if(isset($_POST["submit"]))
							{
								$sq="insert into sub(SNAME) values ('{$_POST["sname"]}')";
								if($db->query($sq))
								{
									echo "<p class='bg-success'><big>Insert Success..</big></p>";
								}
								else
								{
									echo "<p class='bg-danger'><big>Insert failed...</big></p>";
								}
							}
						?>
						
					<center>
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
						   <label><b><h2>Subject </h2></b></label><br>
						   <input type="text" name="sname" required class="input"><br><br>
						   <button type="submit" class="btn btn-primary" name="submit" >Add Subject Details</button>
						</form></center>
<br>

							
				        <div class="card mb-3">
				        	 <div class="alert alert-danger">
            <i class="fas fa-table"></i>
            Subject Data Table </div>
            <div class="card-body">
            <div class=" table-hover table-striped table-bordered">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
               <tbody>
				
				<div class="tbox">
					<?php
						if(isset($_GET["mes"]))
						{
							echo "<p class='bg-danger'><big>{$_GET["mes"]}</big></p>";
						}
					
					?>
							<tr class="text-center">
							<th>S.No</th>
							<th>Subject Name</th>
							<th>Delete</th>
						</tr>
						<?php
							$s="select * from sub";
							$res=$db->query($s);
							if($res->num_rows>0)
							{
								$i=0;
								while($r=$res->fetch_assoc())
								{
									$i++;
									echo "
										<tr>
										<td>{$i}</td>
										<td>{$r["SNAME"]}</td>
										<td><a href='sub_delete.php?id={$r["SID"]}' class='btn btn-danger'>Delete</a></td>
										</tr>
									
									";
									
								}
								
							}
							else
							{
								echo "No Record Found";
							}
						?>
					</tbody>
					</table>
					
				</div></div>
				
	
		<div class="footer">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
		</div>
	</body>
</html>
<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
		<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> view Student</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>
			<body class = "back" id="page-top">
		  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="index.php">Admin Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="admin_home.php">Admin Home</a>&nbsp;&nbsp;
				<a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="logout.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="admin_home.php">
        	          <i class="fas fa-fw fa-folder"></i>

        	          <span>School Information</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="add_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_sub.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Subject</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="add_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Staff</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="view_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View staff</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="set_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Set Exam</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="student.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
      
	  
	  
    </ul>

    		<div id="content-wrapper">

 	<div class="container-fluid">

 
          	<h1 class="alert alert-danger">		Welcome 	<?php echo $_SESSION["ANAME"]; ?></h1>

      



				<div class="section">
			
				
				<div class="content" >


	
		<center>
		<img src="images/qw.jpg" width="600" height="350" class="rounded-circle">
		</center><br>
			
			<div id="section">
				
				
			<div class="section">
					
						<h2 ><center> View Student Details<center></center></h2><br>
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					<div class="lbox1">	
						<label><h4>Class</h4></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<select name="cla" required class="input3">
				
						<?php 
							 $sl="SELECT DISTINCT(CNAME) FROM class";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["CNAME"]}'>{$ro["CNAME"]}</option>";
										}
									}
						?>
					
					</select>
					<br><br>
						
				</div>
				<div class="rbox">
										<label><h4>Section</h4></label>&nbsp;&nbsp;
						<select name="sec" required class="input3">
				
						<?php 
							 $sql="SELECT DISTINCT(CSEC) FROM class";
							$re=$db->query($sql);
								if($re->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($r=$re->fetch_assoc())
										{
											echo "<option value='{$r["CSEC"]}'>{$r["CSEC"]}</option>";
										}
									}
						?>
					
					</select><br><br>
				</div>
					<button type="submit" class="btn btn-primary" name="view"> View Details</button>
				
						
					</form>
								<br>
			<div class="card mb-3">
			<div class="alert alert-success">
				<i class="fas fa-table"></i>
            Class Data Table </div>
            <div class="card-body">
            <div class="table-responsive table-bordered table-hover table-striped">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              	<tbody>
			<div class="Output">
						<?php
							if(isset($_POST["view"]))
							{
								echo "<h3>Student Details</h3><br>";
								$sql="select * from student where SCLASS='{$_POST["cla"]}' and SSEC='{$_POST["sec"]}'";
								$re=$db->query($sql);
								if($re->num_rows>0)
								{
									echo '
					
										<tr>
											<th>S.No</th>
											<th>Roll No</th>
											<th>Name</th>
											<th>Father Name</th>
											<th>DOB</th>
											<th>Gender</th>
											<th>Phone</th>
											<th>Mail</th>
											<th>Address</th>
											<th>Class</th>
											<th>Sec</th>
											<th>Image</th>
										</tr>
									
									
									';
									$i=0;
									while($r=$re->fetch_assoc())
									{
										$i++;
										echo "
										<tr>
											<td>{$i}</td>
											<td>{$r["RNO"]}</td>
											<td>{$r["NAME"]}</td>
											<td>{$r["FNAME"]}</td>
											<td>{$r["DOB"]}</td>
											<td>{$r["GEN"]}</td>
											<td>{$r["PHO"]}</td>
											<td>{$r["MAIL"]}</td>
											<td>{$r["ADDR"]}</td>
											<td>{$r["SCLASS"]}</td>
											<td>{$r["SSEC"]}</td>
											<td><img src='{$r["SIMG"]}' height='70' width='70'></td>
										
										
										</tr>
										";
										
									}
								}
							else
							{
								echo "No record Found";
							}
								echo "</table>";
							}
						
						
						?>
				


							</div>
						</div>
					</div>
					</div>
					
				</div></tbody></table></div></div></div></center>
	
				<div class="footer">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
			</div>
	</body>
</html>
				
					
						

				
<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM staff WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> Admin - Dashboard</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>
	
	<body class = "back" id="page-top">
		  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="index.php">Teacher Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="teacher.php">Teacher Home</a>&nbsp;&nbsp;
				<a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="teacher_login.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="teacher.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="teacher_home.php">
        	          <i class="fas fa-fw fa-folder"></i>

        	          <span>Profile</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="handle_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_stud.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Students</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_stud_teach.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="tech_view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Add Marks</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_mark.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Marks</span></a>
      </li>
   
	 
       
	  
    </ul>
	<div id="content-wrapper">

 	<div class="container-fluid">



 				<div class="card mb-3">
 						          <div class="alert alert-primary">
 					     &nbsp;&nbsp; <h1 class="text" align = "center">	Welcome 	<?php echo $_SESSION["TNAME"]; ?></h1><hr>
</div>
 					                    <div class="card-body">

<div class="container">
<div class="row justify-content-center">
                    <div class="col-md-17">
                        <div class="card">
                            <div class="alert alert-success"><h1> View Student </h1></div>
                            		<center><img src="images/tra.jpg" width="400" height="250" class="rounded"></center><br>
<div id="section">
			
				<div class="section">
					
					
					<?php
						if(isset($_GET["mes"]))
						{
							echo"<p class='bg-warning'>{$_GET["mes"]}</div>";	
						}
					
					?>
						
					<form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER["PHP_SELF"];?>">
				<div class="lbox">	&nbsp;&nbsp;&nbsp;					
					<i class="fa fa-lock fill fa" aria-hidden="true">&nbsp;&nbsp;</i>
					<label> ID</label><br>
						<?php
							$no="S101";
							$sql="select * from student order by ID desc limit 1";
							$res=$db->query($sql);
							if($res->num_rows>0)
							{
								$row1=$res->fetch_assoc();
								$no=substr($row1["RNO"],1,strlen($row1["RNO"]));
								$no++;
								$no="S".$no;
							}
						
						
						
						?>
				 <div class="card mb-3">
				        	 <div class="alert alert-warning"><big>
            <i class="table"></i>
            Class Data Table </big></div>
                        <div class="card-body">
            <div class="table-responsive table-bordered table-hover table-striped">
              <table class="table table-bordered" id="dataTable"  cellspacing="0" align="center">
               <tbody>
						<tr>
							<th>S.No</th>
							<th>Roll No</th>
							<th>Name</th>
							<th>Father Name</th>
							<th>DOB</th>
							<th>Gender</th>
							<th>Phone</th>
							<th>Mail</th>
							<th>Address</th>
							<th>Class</th>
							<th>Sec</th>
							<th>Image</th>
							<th>Delete</th>
						</tr>
				<?php
					$s="select * from student where TID={$_SESSION["TID"]}"; // teacher add only student details not display all student display
							$res=$db->query($s);
							if($res->num_rows>0)		// have record run the loop
							{
								$i=0;
								while($r=$res->fetch_assoc()) //$res valu in array 
								{
									$i++;					//increment every record
									echo"
										<tr>
											<td>{$i}</td>		
											<td>{$r["RNO"]}</td>
											<td>{$r["NAME"]}</td>
											<td>{$r["FNAME"]}</td>
											<td>{$r["DOB"]}</td>
											<td>{$r["GEN"]}</td>
											<td>{$r["PHO"]}</td>
											<td>{$r["MAIL"]}</td>
											<td>{$r["ADDR"]}</td>
											<td>{$r["SCLASS"]}</td>
											<td>{$r["SSEC"]}</td>
											<td><img src='{$r["SIMG"]}' height='100' width='100'></td>
											<td><a href='stud_delete.php?id={$r["ID"]}' class='btn btn-danger'>Delete</a></td>
										</tr>
									
									
									
									";
								}
							}
							else
							{
								echo "No Record Found";
							}
						
						?>
						
					</table>
					
					</div>
				
				
		</div>
			
			<div class="footer1">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
				</div>
				
	</body>
	
</html>
	
				











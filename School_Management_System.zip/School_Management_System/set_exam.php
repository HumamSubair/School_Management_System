<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}	
?>

<!DOCTYPE html>
<html>
		<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> Set Exam</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>
			<body class = "back" id="page-top">
		  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="index.php">Admin Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="admin_home.php">Admin Home</a>&nbsp;&nbsp;
				<a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="logout.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="admin_home.php">
        	          <i class="fas fa-fw fa-folder"></i>

        	          <span>School Information</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="add_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_sub.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Subject</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="add_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Staff</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="view_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View staff</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="set_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Set Exam</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="student.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
       
	  
	  
    </ul>

    		<div id="content-wrapper">

 	<div class="container-fluid">

 <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
          	<h1 class="text" align = "center"><font color="#E75304">		Welcome 	<?php echo $_SESSION["ANAME"]; ?></font></h1>

        </ol>



<div class="section">
			
				
				<div class="content" >


	
		<center>
		<img src="images/am.jpg" width="600" height="350" class="rounded-circle">
		</center><br>
			
				
				
			<div id="section">
			
								
				<div class="section">
					
						<h3 >Set Exam Time Table Details</h3><br>
					<?php
						if(isset($_POST["submit"]))
						{
							$edate=$_POST["dat"].'-'.$_POST["mo"].'-'.$_POST["ye"];
							
							$sq="insert into exam(ENAME,ETYPE,EDATE,SESSION,CLASS,SUB) values ('{$_POST["ename"]}','{$_POST["etype"]}','{$edate}','{$_POST["ses"]}','{$_POST["cla"]}','{$_POST["sub"]}')";
							if($db->query($sq))
							{
								echo "<p class='bg-success'><big>Insert Success..</big></p>";
							}
							else
							{
								echo "<p class='bg-danger'><big>Insert failed...</big></p>";
							}
						}
					?>
					
						<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					
					
					
					<div class="set">
						<label> Exam Name</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<input type="text" class="input3" name="ename"><br><br>
						<label> Select Term</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
							<select name="etype" required class="input3">
						       <option value="">Select</option>
						       <option value="I-Term">I-Term</option>
						       <option value="II-Term">II-Term</option>
						       <option value="III-Term">III-Term</option>
							</select>
					<br><br><br>
					
					<label> Exam Date</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					
					<select name="dat" class="input5">
						<option value="">Date</option>
						<option value="1">1 </option>
						<option value="2">2 </option>
						<option value="3">3 </option>
						<option value="4">4 </option>
						<option value="5">5 </option>
						<option value="6">6 </option>
						<option value="7">7 </option>
						<option value="8">8 </option>
						<option value="9">9 </option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option>
						<option value="24">24</option>
						<option value="25">25</option>
						<option value="26">26</option>
						<option value="27">27</option>
						<option value="28">28</option>
						<option value="29">29</option>
						<option value="30">30</option>
						<option value="31">31</option>
						</select>&nbsp;&nbsp;&nbsp;
					<select name="mo" class="input5">&nbsp;&nbsp;&nbsp;
						<option> Month</option>
						<option value="01">Jan</option>
						<option value="02">Feb</option>
						<option value="03">Mar</option>
						<option value="04">Apr</option>
						<option value="05">May</option>
						<option value="06">Jun</option>
						<option value="07">Jul</option>
						<option value="08">Aug</option>
						<option value="09">Sep</option>
						<option value="10">Oct</option>
						<option value="11">Nov</option>
						<option value="12">Dec</option>
					</select>&nbsp;&nbsp;&nbsp;
					<select name="ye" class="input5">
						<option value="">Select Year</option>
						<option value="2020">2020</option>
						<option value="2019">2019</option>
						<option value="2018">2018</option>
						<option value="2017">2017</option>
						<option value="2016">2016</option>
						<option value="2015">2015</option>
						<option value="2014">2014</option>
						<option value="2013">2013</option>
						<option value="2012">2012</option>
						<option value="2011">2011</option>
						<option value="2010">2010</option>
						<option value="2009">2009</option>
						<option value="2008">2008</option>
						<option value="2007">2007</option>
						<option value="2006">2006</option>
						<option value="2005">2005</option>
						<option value="2004">2004</option>
						<option value="2003">2003</option>
						<option value="2002">2002</option>
						<option value="2001">2001</option>
					</select>
				</div><br><br>
				
				<div class="rbox">
					<label>Session</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<select name="ses" required class="input3">
							<option value="">Select</option>
							<option value="FT">FT</option>
							<option value="PT">PT</option>
						</select>
					<br><br>
					
					
					<label>Class</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<select name="cla" required class="input3">
						<?php
							$sl="select DISTINCT(CNAME) from class"; // section is not repeted to class table
							$r=$db->query($sl);
							if($r->num_rows>0)
							{
								echo 	"<option value=''>Select</option>";
								while($ro=$r->fetch_assoc())
								{
									echo "<option value='{$ro["CNAME"]}'>{$ro["CNAME"]}</option>";
								}
								
							}
						?>	
						
					</select>
					
					<br><br>
					
					
					<label>Subject</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<select name="sub" required class="input3">
						<?php
							$s="select * from sub";
							$re=$db->query($s);
							if($re->num_rows>0)
							{
								echo "<option value=''>select</option>";
								while($r=$re->fetch_assoc())
								{
									echo "<option value='{$r["SNAME"]}'>{$r["SNAME"]}</option>";
								}
							}
						?>
						
					</select>
					<br><br>
				</div>
					<button type="submit" class="btn btn-primary" name="submit">Add Exam Details</button>
				</form>
				


					
				</div>
				
	
		<div class="footer">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
		</div>
	</body>
</html>
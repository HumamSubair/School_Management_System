<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
		
	}
	$sql="SELECT * FROM staff WHERE TID={$_GET["id"]}"; //search tid = staff tid run the loop
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}	
?>

<!DOCTYPE html>
<html>
    <head>
  
     <meta charset="utf-8">
       <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title> View Staff</title>
      <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
    
  </head>

      <body class = "back" id="page-top">
      <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
        <a class="navbar-brand mr-1" href="index.php">Admin Menu </a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
          <i class="fas fa-bars"></i>
       </button>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5> 
        <a href="admin_home.php">Admin Home</a>&nbsp;&nbsp;
        <a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
        <a href="logout.php">Logout</a>&nbsp;&nbsp;
        </h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="admin_home.php">
                    <i class="fas fa-fw fa-folder"></i>

                    <span>School Information</span></a>

        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="add_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_sub.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Subject</span></a>
      </li>
        <li class="nav-item">
        <a class="nav-link"  href="add_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Staff</span></a>
      </li>
   
    <li class="nav-item">
        <a class="nav-link"  href="view_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View staff</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="set_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Set Exam</span></a>
      </li>
        <li class="nav-item">
        <a class="nav-link"  href="view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
   
    <li class="nav-item">
        <a class="nav-link"  href="student.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
       
    
    </ul>

        <div id="content-wrapper">

  <div class="container-fluid">

 <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <h1 class="text" align = "center"><font color="blue">  View Staff </font></h1>

        </ol>
			
			
			<div id="section">
			
				
				<div class="section">
					
						<div class="container" style="padding-left:20%;">
			<div class="row">
				<div class="col-lg-6"><center>
					               <table class="table table-user-information">
					               						<div class = "side" >

					<div class="rbox1">
					
							<tr><td colspan="4"><center><img src="<?php echo $row["IMG"] ?>" height="200" width="200" alt="upload Pending" ></center>
							</td></tr>
							<tr><th>Name </th> <td><?php echo $row["TNAME"] ?> </td></tr>
							<tr><th>Qualification </th> <td><?php echo $row["QUAL"] ?>  </td></tr>
							<tr><th>Salary </th> <td> <?php echo $row["SAL"] ?>  </td></tr>
							<tr><th>Phone No </th> <td> <?php echo $row["PNO"] ?> </td></tr>
							<tr><th>E - Mail </th> <td> <?php echo $row["MAIL"] ?> </td></tr>
							<tr><th>Address </th> <td> <?php echo $row["PADDR"] ?> </td></tr></center>

						</table>
						</div>
						
						
			</div>
		
			
			
			
	</body>
</html>
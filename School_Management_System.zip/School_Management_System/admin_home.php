<?php
	include"database.php";
	session_start();
	if (!isset($_SESSION["AID"]))
	{
		echo "<script>window.open('admin.php?mes=Access Denied..','_self')</script>";
	}
			
?>

<!DOCTYPE html>
<html>
	<head>
	
		 <meta charset="utf-8">
  		 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  		<meta name="description" content="">
  		<meta name="author" content="">
  		<title> Admin - Dashboard</title>
  		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

   <link href="css/sb-admin.css" rel="stylesheet">
		
	</head>
	<body class = "back" id="page-top">
		  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    		<a class="navbar-brand mr-1" href="index.php">Admin Menu </a>
			<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
    		  <i class="fas fa-bars"></i>
   		 </button>
   		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>	
				<a href="admin_home.php">Admin Home</a>&nbsp;&nbsp;
				<a href="admin_change_pass.php">Settings</a>&nbsp;&nbsp;
				<a href="logout.php">Logout</a>&nbsp;&nbsp;
				</h5>
     <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-primary" type="button">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>
</nav>
  <div id="wrapper">
<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="admin_home.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
    </li>
     <li class="nav-item ">
        <a class="nav-link" href="admin_home.php">
        	          <i class="fas fa-fw fa-folder"></i>

        	          <span>School Information</span></a>

        </a>
		</li>
		<li class="nav-item">
        <a class="nav-link" href="add_class.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>class</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="add_sub.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Subject</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="add_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Staff</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="view_staff.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View staff</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link"  href="set_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Set Exam</span></a>
      </li>
	  	  <li class="nav-item">
        <a class="nav-link"  href="view_exam.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Exam</span></a>
      </li>
   
	  <li class="nav-item">
        <a class="nav-link"  href="student.php">
          <i class="fas fa-fw fa-table"></i>
          <span>View Student</span></a>
      </li>
        
	  
	  
    </ul>
	<div id="content-wrapper">

 	<div class="container-fluid">

 
         
		<h1 class="alert alert-primary">		Welcome 	<?php echo $_SESSION["ANAME"]; ?></h1>
         
       



			<div class="section">
			
				
				<div class="content" >
					
						<h2 class="text-center" > <font color="#B31E1A">School Information</font></h2><br><br>
			<center>		<img src="images/sy.jpg"  alt="sy"width="200px;" class="thumbnail"/><br><br></center>
					<p class="text-justify"><b><big>
						C.O. Lesthakir International College was established in the year 2004 in Nintavur with the sole objective of high standard English medium education to those students in the Eastern Province thus enabling our students to be on par with the students in the other regions. This effort of ours is a tribute to the late Mr. C.O. Lesthakir, a prominent educationist of the region who strived hard to uplift the standard of English in the region.
Fluency in English in addition to higher professional qualification is the passport to success. The need has been recognised by one and all. Our College is providing such an environment to all our students.</b>
					</p>
					
					<p class="para"><b>
						About 200 students are studying in the school Mr. I.M. Issadeen is the principle and managing Director of the school.
						Two kind of section in the school<b></p></big> </p>
							<li>L.K.G to grade 2</li>
							<li>Grade 3 to O/L</li><br><br>
<div class ="images" align="center" style = "margin-top: 50px;">
		
			
			<img src="images/sa.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/skb.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/ta.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/ov.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/pa.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/tr.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>	
			<img src="images/gr.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/anu.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/ni.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/fn.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/st.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/pl.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/red.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
			<img src="images/kl.jpg" width="600" height="350" style = " border : solid 4px; margin-bottom : 4px;"/>
	
		</div>
		
		
		<div class="footer">
				<p><b><center><h4>	Copyright &copy; SMS 	</h4></center></b></p>
		</div>
	</body>
</html>
					
			
	
		
		
					
			
		
				
				
			

					
			
	
	
		

		